using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using RunWay.Models;

namespace RunWay.Data;

public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
    public DbSet<Participant> Participants => Set<Participant>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.Entity<ApplicationUser>().Property(u => u.FirstName).HasMaxLength(80).IsRequired();
        builder.Entity<ApplicationUser>().Property(u => u.LastName).HasMaxLength(80).IsRequired();
        builder.Entity<Participant>()
            .HasOne(p => p.ApplicationUser).WithMany()
            .HasForeignKey(p => p.ApplicationUserId).OnDelete(DeleteBehavior.Cascade);
        builder.Entity<Participant>().HasIndex(p => p.ApplicationUserId);
    }
}

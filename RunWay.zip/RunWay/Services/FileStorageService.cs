namespace RunWay.Services;

public interface IFileStorageService
{
    Task<string> SaveAsync(IFormFile file, string folder, CancellationToken cancellationToken = default);
    Task DeleteAsync(string? relativePath);
}

public sealed class FileStorageService : IFileStorageService
{
    private readonly IWebHostEnvironment _environment;
    private static readonly HashSet<string> AllowedExtensions = new(StringComparer.OrdinalIgnoreCase) { ".jpg", ".jpeg", ".png", ".webp", ".pdf" };
    public FileStorageService(IWebHostEnvironment environment) => _environment = environment;

    public async Task<string> SaveAsync(IFormFile file, string folder, CancellationToken cancellationToken = default)
    {
        if (file.Length <= 0 || file.Length > 5 * 1024 * 1024) throw new InvalidOperationException("File must be between 1 byte and 5 MB.");
        var extension = Path.GetExtension(Path.GetFileName(file.FileName));
        if (!AllowedExtensions.Contains(extension)) throw new InvalidOperationException("Allowed file types are JPG, PNG, WEBP and PDF.");
        var safeFolder = Path.GetFileName(folder);
        var directory = Path.Combine(_environment.WebRootPath, "uploads", safeFolder);
        Directory.CreateDirectory(directory);
        var fileName = $"{Guid.NewGuid():N}{extension.ToLowerInvariant()}";
        var fullPath = Path.Combine(directory, fileName);
        await using var stream = new FileStream(fullPath, FileMode.CreateNew, FileAccess.Write, FileShare.None);
        await file.CopyToAsync(stream, cancellationToken);
        return $"/uploads/{safeFolder}/{fileName}";
    }

    public Task DeleteAsync(string? relativePath)
    {
        if (string.IsNullOrWhiteSpace(relativePath) || !relativePath.StartsWith("/uploads/", StringComparison.Ordinal)) return Task.CompletedTask;
        var relative = relativePath.TrimStart('/').Replace('/', Path.DirectorySeparatorChar);
        var fullPath = Path.GetFullPath(Path.Combine(_environment.WebRootPath, relative));
        var root = Path.GetFullPath(Path.Combine(_environment.WebRootPath, "uploads")) + Path.DirectorySeparatorChar;
        if (fullPath.StartsWith(root, StringComparison.Ordinal) && File.Exists(fullPath)) File.Delete(fullPath);
        return Task.CompletedTask;
    }
}

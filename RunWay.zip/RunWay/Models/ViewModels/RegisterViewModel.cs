using System.ComponentModel.DataAnnotations;

namespace RunWay.Models.ViewModels;

public class RegisterViewModel
{
    [Required, StringLength(80)] [Display(Name = "First name")] public string FirstName { get; set; } = string.Empty;
    [Required, StringLength(80)] [Display(Name = "Last name")] public string LastName { get; set; } = string.Empty;
    [Required, EmailAddress] public string Email { get; set; } = string.Empty;
    [Phone] [Display(Name = "Phone number")] public string? PhoneNumber { get; set; }
    [Required, DataType(DataType.Password), MinLength(8)] public string Password { get; set; } = string.Empty;
    [Required, DataType(DataType.Password), Compare(nameof(Password))] [Display(Name = "Confirm password")] public string ConfirmPassword { get; set; } = string.Empty;
    [Required] [Display(Name = "Account role")] public string Role { get; set; } = "Participant";
    [Display(Name = "Race category")] public string RaceCategory { get; set; } = "5 km";
}

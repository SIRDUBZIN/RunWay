using RunWay.Models;
namespace RunWay.Models.ViewModels;
public class AdminDashboardViewModel
{
    public int TotalParticipants { get; set; }
    public int RegisteredParticipants { get; set; }
    public int PendingParticipants { get; set; }
    public int TotalUsers { get; set; }
    public List<Participant> RecentParticipants { get; set; } = new();
}

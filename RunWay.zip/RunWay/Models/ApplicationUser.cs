using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace RunWay.Models;

public class ApplicationUser : IdentityUser
{
    [Required, StringLength(80)] public string FirstName { get; set; } = string.Empty;
    [Required, StringLength(80)] public string LastName { get; set; } = string.Empty;
    [StringLength(260)] public string? ProfileImagePath { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
}

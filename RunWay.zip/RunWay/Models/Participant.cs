using System.ComponentModel.DataAnnotations;

namespace RunWay.Models;

public class Participant
{
    public int Id { get; set; }
    [Required] public string ApplicationUserId { get; set; } = string.Empty;
    public ApplicationUser? ApplicationUser { get; set; }
    [Required, StringLength(120)] public string EventName { get; set; } = "RunWay Community Run";
    [Required, StringLength(30)] public string RaceCategory { get; set; } = "5 km";
    [Required, StringLength(30)] public string RegistrationStatus { get; set; } = "Registered";
    public DateTime RegisteredAtUtc { get; set; } = DateTime.UtcNow;
}

/* RunWay feature schema reference for SQL Server.
   For an existing Identity database, use EF Core migrations as documented in README.md.
   This script contains the feature tables/columns only and is not a replacement for the Identity schema. */
IF OBJECT_ID(N'dbo.Participants', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Participants (
        Id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Participants PRIMARY KEY,
        ApplicationUserId NVARCHAR(450) NOT NULL,
        EventName NVARCHAR(120) NOT NULL CONSTRAINT DF_Participants_EventName DEFAULT N'RunWay Community Run',
        RaceCategory NVARCHAR(30) NOT NULL CONSTRAINT DF_Participants_RaceCategory DEFAULT N'5 km',
        RegistrationStatus NVARCHAR(30) NOT NULL CONSTRAINT DF_Participants_RegistrationStatus DEFAULT N'Registered',
        RegisteredAtUtc DATETIME2 NOT NULL CONSTRAINT DF_Participants_RegisteredAtUtc DEFAULT SYSUTCDATETIME(),
        CONSTRAINT FK_Participants_AspNetUsers_ApplicationUserId FOREIGN KEY (ApplicationUserId)
            REFERENCES dbo.AspNetUsers(Id) ON DELETE CASCADE
    );
    CREATE INDEX IX_Participants_ApplicationUserId ON dbo.Participants(ApplicationUserId);
END;
GO
IF COL_LENGTH('dbo.AspNetUsers', 'FirstName') IS NULL ALTER TABLE dbo.AspNetUsers ADD FirstName NVARCHAR(80) NOT NULL CONSTRAINT DF_AspNetUsers_FirstName DEFAULT N'';
GO
IF COL_LENGTH('dbo.AspNetUsers', 'LastName') IS NULL ALTER TABLE dbo.AspNetUsers ADD LastName NVARCHAR(80) NOT NULL CONSTRAINT DF_AspNetUsers_LastName DEFAULT N'';
GO
IF COL_LENGTH('dbo.AspNetUsers', 'ProfileImagePath') IS NULL ALTER TABLE dbo.AspNetUsers ADD ProfileImagePath NVARCHAR(260) NULL;
GO
IF COL_LENGTH('dbo.AspNetUsers', 'CreatedAtUtc') IS NULL ALTER TABLE dbo.AspNetUsers ADD CreatedAtUtc DATETIME2 NOT NULL CONSTRAINT DF_AspNetUsers_CreatedAtUtc DEFAULT SYSUTCDATETIME();
GO

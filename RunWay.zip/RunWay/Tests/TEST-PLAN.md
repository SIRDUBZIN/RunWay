# RunWay manual and integration test plan

| ID | Scenario | Expected result |
|---|---|---|
| T01 | Register with valid details | User, Participant role membership, and participant row are created |
| T02 | Register as Organiser | Organiser role is assigned and no participant row is created |
| T03 | Register with duplicate email | Registration is rejected with a validation message |
| T04 | Submit invalid email, missing names, or mismatched passwords | Model validation prevents account creation |
| T05 | Log in with correct credentials | User is authenticated and redirected according to role |
| T06 | Log in with incorrect credentials | Generic login error is shown; repeated failures trigger Identity lockout |
| T07 | Participant requests `/Admin` | Request is denied; dashboard data is not disclosed |
| T08 | Participant requests `/Participants` | Request is denied because the list is Admin-only |
| T09 | Participant opens own registration | Only their own registration record is displayed |
| T10 | Admin opens dashboard | Aggregate counts and recent participants are displayed |
| T11 | Admin updates status | Only Registered, Confirmed, and Cancelled are accepted; change persists |
| T12 | Admin searches participants | Name/email matches are returned; empty results are handled |
| T13 | Seed roles on clean database | Admin and Participant roles exist and repeated startup is idempotent |
| T14 | Configure seed admin | Account is created once and assigned Admin role |
| T15 | Upload service accepts JPG/PNG/WEBP/PDF under 5 MB | Generated filename is stored under `wwwroot/uploads` |
| T16 | Upload service rejects unsupported or oversized files | An `InvalidOperationException` is raised and no file is saved |
| T17 | Database unavailable during startup | Startup logs the migration failure and stops instead of running against a missing schema |

Run these tests after applying migrations and configuring a development SQL Server database. Do not use real participant data in development tests.

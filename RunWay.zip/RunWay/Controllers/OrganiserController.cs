using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RunWay.Data;
using Microsoft.EntityFrameworkCore;

namespace RunWay.Controllers;

[Authorize(Roles = "Organiser")]
public class OrganiserController : Controller
{
    private readonly ApplicationDbContext _db;
    public OrganiserController(ApplicationDbContext db) => _db = db;
    public async Task<IActionResult> Index()
    {
        ViewBag.TotalParticipants = await _db.Participants.CountAsync();
        ViewBag.RegisteredParticipants = await _db.Participants.CountAsync(p => p.RegistrationStatus == "Registered");
        return View();
    }
}

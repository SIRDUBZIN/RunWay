using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RunWay.Data;
using RunWay.Models;

namespace RunWay.Controllers;

[Authorize]
public class ParticipantsController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;
    public ParticipantsController(ApplicationDbContext db, UserManager<ApplicationUser> userManager) { _db = db; _userManager = userManager; }

    [HttpGet]
    public async Task<IActionResult> MyRegistration()
    {
        var userId = _userManager.GetUserId(User);
        var participant = await _db.Participants.Include(p => p.ApplicationUser).FirstOrDefaultAsync(p => p.ApplicationUserId == userId);
        return participant == null ? NotFound() : View(participant);
    }

    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Index(string? search)
    {
        var query = _db.Participants.Include(p => p.ApplicationUser).AsNoTracking();
        if (!string.IsNullOrWhiteSpace(search)) query = query.Where(p => p.ApplicationUser!.FirstName.Contains(search) || p.ApplicationUser.LastName.Contains(search) || p.ApplicationUser.Email!.Contains(search));
        ViewBag.Search = search;
        return View(await query.OrderByDescending(p => p.RegisteredAtUtc).ToListAsync());
    }

    [Authorize(Roles = "Admin"), HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> UpdateStatus(int id, string status)
    {
        if (status is not ("Registered" or "Confirmed" or "Cancelled")) return BadRequest();
        var participant = await _db.Participants.FindAsync(id);
        if (participant == null) return NotFound();
        participant.RegistrationStatus = status;
        await _db.SaveChangesAsync();
        TempData["Success"] = "Participant status updated.";
        return RedirectToAction(nameof(Index));
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RunWay.Data;
using RunWay.Models;
using RunWay.Models.ViewModels;

namespace RunWay.Controllers;

public class AccountController : Controller
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly ApplicationDbContext _db;
    public AccountController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager, ApplicationDbContext db)
    { _userManager = userManager; _signInManager = signInManager; _db = db; }

    [AllowAnonymous, HttpGet]
    public IActionResult Register() => User.Identity?.IsAuthenticated == true ? RedirectToAction("Index", "Home") : View(new RegisterViewModel());

    [AllowAnonymous, HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (!ModelState.IsValid) return View(model);
        if (model.Role is not ("Participant" or "Organiser")) { ModelState.AddModelError(nameof(model.Role), "Choose a valid account role."); return View(model); }
        var user = new ApplicationUser { UserName = model.Email.Trim(), Email = model.Email.Trim(), FirstName = model.FirstName.Trim(), LastName = model.LastName.Trim(), PhoneNumber = model.PhoneNumber, EmailConfirmed = true };
        var result = await _userManager.CreateAsync(user, model.Password);
        if (!result.Succeeded) { foreach (var error in result.Errors) ModelState.AddModelError(string.Empty, error.Description); return View(model); }
        var roleResult = await _userManager.AddToRoleAsync(user, model.Role);
        if (!roleResult.Succeeded)
        {
            await _userManager.DeleteAsync(user);
            foreach (var error in roleResult.Errors) ModelState.AddModelError(string.Empty, error.Description);
            return View(model);
        }
        if (model.Role == "Participant")
            _db.Participants.Add(new Participant { ApplicationUserId = user.Id, RaceCategory = model.RaceCategory, EventName = "RunWay Community Run" });
        await _db.SaveChangesAsync();
        await _signInManager.SignInAsync(user, isPersistent: false);
        TempData["Success"] = "Registration complete. Welcome to RunWay!";
        return model.Role == "Organiser" ? RedirectToAction("Index", "Organiser") : RedirectToAction("MyRegistration", "Participants");
    }

    [AllowAnonymous, HttpGet]
    public IActionResult Login(string? returnUrl = null) => View(new LoginViewModel { ReturnUrl = returnUrl });

    [AllowAnonymous, HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (!ModelState.IsValid) return View(model);
        var user = await _userManager.FindByEmailAsync(model.Email.Trim());
        if (user == null) { ModelState.AddModelError(string.Empty, "Invalid email or password."); return View(model); }
        var result = await _signInManager.PasswordSignInAsync(user, model.Password, model.RememberMe, lockoutOnFailure: true);
        if (result.Succeeded)
        {
            if (!string.IsNullOrWhiteSpace(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl)) return LocalRedirect(model.ReturnUrl);
            if (await _userManager.IsInRoleAsync(user, "Admin")) return RedirectToAction("Index", "Admin");
            if (await _userManager.IsInRoleAsync(user, "Organiser")) return RedirectToAction("Index", "Organiser");
            return RedirectToAction("MyRegistration", "Participants");
        }
        ModelState.AddModelError(string.Empty, result.IsLockedOut ? "Account temporarily locked. Try again later." : "Invalid email or password.");
        return View(model);
    }

    [Authorize, HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout() { await _signInManager.SignOutAsync(); return RedirectToAction("Index", "Home"); }
}

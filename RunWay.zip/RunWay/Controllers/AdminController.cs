using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RunWay.Data;
using RunWay.Models;
using RunWay.Models.ViewModels;

namespace RunWay.Controllers;

[Authorize(Roles = "Admin")]
public class AdminController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<ApplicationUser> _users;
    public AdminController(ApplicationDbContext db, UserManager<ApplicationUser> users) { _db = db; _users = users; }
    public async Task<IActionResult> Index()
    {
        var model = new AdminDashboardViewModel
        {
            TotalParticipants = await _db.Participants.CountAsync(),
            RegisteredParticipants = await _db.Participants.CountAsync(p => p.RegistrationStatus == "Registered"),
            PendingParticipants = await _db.Participants.CountAsync(p => p.RegistrationStatus == "Pending"),
            TotalUsers = await _users.Users.CountAsync(),
            RecentParticipants = await _db.Participants.Include(p => p.ApplicationUser).AsNoTracking().OrderByDescending(p => p.RegisteredAtUtc).Take(8).ToListAsync()
        };
        return View(model);
    }
}
